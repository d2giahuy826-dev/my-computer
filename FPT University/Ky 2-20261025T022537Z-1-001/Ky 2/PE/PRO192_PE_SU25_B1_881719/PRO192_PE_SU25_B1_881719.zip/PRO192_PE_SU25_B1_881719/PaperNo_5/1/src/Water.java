/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */

/**
 *
 * @author khanh
 */
public class Water {

    private String source;
    private int volume;

    public Water() {
    }

    public Water(String source, int volume) {
        this.source = source;
        this.volume = volume;
    }

    public String getSource() {

        return source.charAt(0) + "" + source.charAt(source.length() - 1) + volume;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        String s = volume + "";
        int n = s.length();
        this.volume = volume * n;
    }

}
