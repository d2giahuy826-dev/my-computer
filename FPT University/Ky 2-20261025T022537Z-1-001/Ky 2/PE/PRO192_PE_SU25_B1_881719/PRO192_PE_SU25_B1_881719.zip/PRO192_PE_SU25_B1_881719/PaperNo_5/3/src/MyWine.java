
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
/**
 *
 * @author khanh
 */
public class MyWine implements IWine {

    @Override
    public String f1(List<Wine> t) {
        for (int i = 0; i < t.size(); i++) {
            int n = t.get(i).getYear();
            if (n % 3 != 0) {
                return t.get(i).getBrand();
            }
        }
        return "Notfound";
    }

    public boolean isPrime(int n) {

        if (n < 2) {
            return false;
        }

        if (n == 2) {
            return true;
        }

        if (n
                % 2 == 0) {
            return false;
        }
        for (int i = 3; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }

        return true;

    }

    @Override
    public void f2(List<Wine> t) {
        for (Wine w : t) {
            if (!isPrime(w.getBrand().length())) {
                String n = String.valueOf(w.getYear());
                char c = n.charAt(0);
                String target = "PRE" + c;
                w.setBrand(target);
            }
        }
    }

    @Override
    public void f3(List<Wine> t) {
        int min = Integer.MAX_VALUE;
        int vitri = 0;
        for (int i = 0; i < t.size(); i++) {
            char c = t.get(i).getBrand().charAt(0);
            if (Character.isLowerCase(c)) {
                if (min > t.get(i).getYear()) {
                    min = t.get(i).getYear();
                    vitri = i;
                }
            }
        }
        t.remove(t.get(vitri));

    }
}
