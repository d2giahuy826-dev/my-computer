
import java.util.HashMap;
import java.util.Map;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
/**
 *
 * @author khanh
 */
public class MyString implements IString {

    @Override
    public int f1(String string) {
        int a = Integer.MIN_VALUE;

        char s = '{';
        HashMap<Character, Integer> map = new HashMap();
        char c[] = string.toCharArray();
        for (char d : c) {
            if (Character.isLowerCase(d)) {
                map.put(d, map.getOrDefault(d, 0) + 1);
            }
        }

        if (map.isEmpty()) {
            return -1;
        }

        for (Map.Entry<Character, Integer> entry : map.entrySet()) {
            char key = entry.getKey();
            int val = entry.getValue();
            if (val > a) {
                a = val;
                s = key;
            } else if (val == a) {
                if (key < s) {
                    s = key;
                }
            }

        }
        return (int) s;
    }

    @Override
    public String f2(String string) {
        String result = "";
        String tempUpper = ""; // Dùng để gom các chữ hoa liên tiếp

        for (int i = 0; i < string.length(); i++) {
            char c = string.charAt(i);

            if (Character.isUpperCase(c)) {
                // Nếu là chữ hoa, gom vào biến tạm
                tempUpper += c;
            } else {
                // Nếu gặp chữ thường/ký tự đặc biệt:
                // 1. Đảo ngược nhóm chữ hoa trước đó (nếu có) và cộng vào result
                if (!tempUpper.isEmpty()) {
                    result += new StringBuilder(tempUpper).reverse().toString();
                    tempUpper = ""; // Xóa biến tạm để gom nhóm mới
                }
                // 2. Cộng ký tự hiện tại vào result
                result += c;
            }
        }

        // Quan trọng: Sau khi hết vòng lặp, nếu vẫn còn chữ hoa ở cuối chuỗi
        if (!tempUpper.isEmpty()) {
            result += new StringBuilder(tempUpper).reverse().toString();
        }

        return result;
    }

}
