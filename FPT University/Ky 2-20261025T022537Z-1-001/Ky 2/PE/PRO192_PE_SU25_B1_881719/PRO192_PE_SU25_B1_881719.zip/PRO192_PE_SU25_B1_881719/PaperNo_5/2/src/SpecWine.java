/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */

/**
 *
 * @author khanh
 */
public class SpecWine extends Wine {

    private String taste;

    public SpecWine() {
    }

    public SpecWine(String taste) {
        this.taste = taste;
    }

    public SpecWine(String brand, int year, String taste) {
        super(brand, year);
        this.taste = taste;
    }

    public String getTaste() {
        return taste;
    }

    public void setData() {
        String s = brand;
        StringBuilder sb = new StringBuilder(s.toUpperCase());
        this.brand = sb.reverse().toString();
    }

    public String getValue() {
        int n = taste.length();
        int m = this.getYear();
        String s = "";
        if (n > m) {
            s = taste.toLowerCase();
            return s;
        } else {
            s = taste.toUpperCase();
            return s;
        }
    }

}
