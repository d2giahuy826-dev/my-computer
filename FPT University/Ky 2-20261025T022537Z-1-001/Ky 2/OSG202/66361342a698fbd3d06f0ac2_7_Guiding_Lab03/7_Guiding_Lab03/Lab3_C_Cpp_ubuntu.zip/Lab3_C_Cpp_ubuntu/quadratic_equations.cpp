#include <iostream>
#include <cmath>

using namespace std;

int main() {
    double a, b, c, x1, x2, discriminant;
    
    cout << "Enter the coefficients a, b, and c: ";
    cin >> a >> b >> c;
    
    discriminant = b*b - 4*a*c;
    
    if (discriminant > 0) {
        x1 = (-b + sqrt(discriminant)) / (2*a);
        x2 = (-b - sqrt(discriminant)) / (2*a);
        cout << "The roots are real and different." << endl;
        cout << "x1 = " << x1 << endl;
        cout << "x2 = " << x2 << endl;
    } else if (discriminant == 0) {
        cout << "The roots are real and equal." << endl;
        x1 = -b / (2*a);
        cout << "x1 = x2 = " << x1 << endl;
    } else {
        cout << "The roots are complex and different." << endl;
        cout << "x1 = (-" << b << "+i" << sqrt(-discriminant) << ")/" << 2*a << endl;
        cout << "x2 = (-" << b << "-i" << sqrt(-discriminant) << ")/" << 2*a << endl;
    }
    
    return 0;
}

