#include <iostream>

int main()
{
  int choice;
  
  while (true)
  {
    std::cout << "Menu:" << std::endl;
    std::cout << "1. Option 1" << std::endl;
    std::cout << "2. Option 2" << std::endl;
    std::cout << "3. Option 3" << std::endl;
    std::cout << "4. Quit" << std::endl;
    std::cout << "Enter your choice: ";
    std::cin >> choice;
    
    if (choice == 1)
    {
      std::cout << "You chose Option 1" << std::endl;
    }
    else if (choice == 2)
    {
      std::cout << "You chose Option 2" << std::endl;
    }
    else if (choice == 3)
    {
      std::cout << "You chose Option 3" << std::endl;
    }
    else if (choice == 4)
    {
      std::cout << "Goodbye!" << std::endl;
      break;
    }
    else
    {
      std::cout << "Invalid choice. Try again." << std::endl;
    }
  }
  
  return 0;
}

