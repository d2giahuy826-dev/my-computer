#include <stdio.h>

int main(void) {
    printf("Hello, World!C in ubuntu\n");
    return 0;
}

