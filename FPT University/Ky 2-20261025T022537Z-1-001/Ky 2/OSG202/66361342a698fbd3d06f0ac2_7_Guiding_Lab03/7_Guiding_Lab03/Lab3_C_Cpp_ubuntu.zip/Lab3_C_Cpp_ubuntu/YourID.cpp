#include <iostream>

int main() {
    std::cout << "Hello, World! Cpp in ubuntu" << std::endl;
    return 0;
}

