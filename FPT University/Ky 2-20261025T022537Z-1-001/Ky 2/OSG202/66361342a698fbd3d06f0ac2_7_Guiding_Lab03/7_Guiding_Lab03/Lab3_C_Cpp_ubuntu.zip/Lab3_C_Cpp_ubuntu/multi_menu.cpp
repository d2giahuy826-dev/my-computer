#include <iostream>
#include <cmath>

using namespace std;

void solveQuadratic() {
    double a, b, c;
    double x1, x2;
    cout << "Enter the coefficients of the quadratic equation (a, b, c): ";
    cin >> a >> b >> c;
    double discriminant = b * b - 4 * a * c;
    if (discriminant >= 0) {
        x1 = (-b + sqrt(discriminant)) / (2 * a);
        x2 = (-b - sqrt(discriminant)) / (2 * a);
        cout << "The roots of the equation are: " << x1 << " and " << x2 << endl;
    }
    else {
        cout << "The equation has no real roots." << endl;
    }
}

void calculateAverage() {
    double math, physics, chemistry, history, geography, english;
    cout << "Enter the scores in Math, Physics, Chemistry, History, Geography, and English: ";
    cin >> math >> physics >> chemistry >> history >> geography >> english;
    double average = (math + physics + chemistry + history + geography + english) / 6;
    cout << "The average score is: " << average << endl;
}

int main() {
    int choice;
    do {
        cout << "1. Solve quadratic equation" << endl;
        cout << "2. Calculate average score" << endl;
        cout << "3. Quit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1:
                solveQuadratic();
                break;
            case 2:
                calculateAverage();
                break;
            case 3:
                break;
            default:
                cout << "Invalid choice. Please enter a valid choice." << endl;
        }
    } while (choice != 3);
    return 0;
}

