package com.fpt.aita.dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBContext {
    protected Connection connection;

    public DBContext() {
        try {
            // Thay đổi user và password theo tài khoản SQL Server của bạn
            String user = "sa";
            String pass = "sa123"; 
String url = "jdbc:sqlserver://localhost;instanceName=LANTHUN;databaseName=AST_CodeAnalysisDB;encrypt=true;trustServerCertificate=true";

            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connection = DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException | SQLException ex) {
            System.err.println("Lỗi kết nối CSDL: " + ex.getMessage());
        }
    }
    public static void main(String[] args) {
    DBContext db = new DBContext();
    if (db.connection != null) {
        System.out.println("===> KẾT NỐI DATABASE THÀNH CÔNG!");
    } else {
        System.out.println("===> KẾT NỐI DATABASE THẤT BẠI! Hãy kiểm tra user/pass/port.");
    }
}

}
