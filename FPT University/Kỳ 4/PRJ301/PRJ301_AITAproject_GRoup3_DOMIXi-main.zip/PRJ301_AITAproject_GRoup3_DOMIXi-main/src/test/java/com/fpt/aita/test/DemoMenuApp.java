package com.fpt.aita.test;

import com.fpt.aita.dal.AssignmentDAO;
import com.fpt.aita.dal.UserDAO;
import com.fpt.aita.model.Assignment;
import com.fpt.aita.model.User;
import java.util.List;
import java.util.Scanner;

public class DemoMenuApp {

    private static final Scanner scanner = new Scanner(System.in);
    private static final UserDAO userDAO = new UserDAO();
    private static final AssignmentDAO assignmentDAO = new AssignmentDAO();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n==========================================");
            System.out.println("   HỆ THỐNG QUẢN LÝ AITA - TEST CRUD MENU ");
            System.out.println("==========================================");
            System.out.println("1. Quản lý USERS (CRUD)");
            System.out.println("2. Quản lý ASSIGNMENTS (CRUD)");
            System.out.println("0. Thoát chương trình");
            System.out.println("==========================================");
            System.out.print("Mời bạn chọn chức năng [0-2]: ");

            int choice = readInt();
            switch (choice) {
                case 1:
                    menuUser();
                    break;
                case 2:
                    menuAssignment();
                    break;
                case 0:
                    System.out.println("\n===> Tạm biệt! Kết thúc chương trình demo.");
                    return;
                default:
                    System.out.println("Lựa chọn không hợp lệ! Vui lòng nhập từ 0 đến 2.");
            }
        }
    }

    // =========================================================================
    // MENU USER CRUD
    // =========================================================================
    private static void menuUser() {
        while (true) {
            System.out.println("\n------------------------------------------");
            System.out.println("       --- QUẢN LÝ USERS (CRUD) ---       ");
            System.out.println("------------------------------------------");
            System.out.println("1. [READ]   Xem danh sách tất cả User");
            System.out.println("2. [READ]   Tìm User theo ID hoặc Username");
            System.out.println("3. [CREATE] Thêm mới User");
            System.out.println("4. [UPDATE] Cập nhật thông tin User");
            System.out.println("5. [DELETE] Xóa User");
            System.out.println("0. Quay lại Menu chính");
            System.out.println("------------------------------------------");
            System.out.print("Chọn thao tác User [0-5]: ");

            int choice = readInt();
            switch (choice) {
                case 1:
                    readAllUsers();
                    break;
                case 2:
                    findUser();
                    break;
                case 3:
                    createUser();
                    break;
                case 4:
                    updateUser();
                    break;
                case 5:
                    deleteUser();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Lựa chọn không hợp lệ! Vui lòng nhập lại.");
            }
        }
    }

    private static void readAllUsers() {
        System.out.println("\n--- DANH SÁCH USERS HIỆN CÓ ---");
        List<User> list = userDAO.getAllUsers();
        if (list.isEmpty()) {
            System.out.println("Danh sách trống!");
            return;
        }
        System.out.printf("%-6s | %-15s | %-25s | %-12s | %-10s\n", "ID", "Username", "Họ tên", "Vai trò", "Mã lớp");
        System.out.println("-----------------------------------------------------------------------------");
        for (User u : list) {
            System.out.printf("%-6d | %-15s | %-25s | %-12s | %-10s\n",
                    u.getUserId(),
                    u.getUsername(),
                    u.getFullName(),
                    u.getRole(),
                    u.getClassId() == null ? "None" : u.getClassId());
        }
    }

    private static void findUser() {
        System.out.println("\n1. Tìm theo ID");
        System.out.println("2. Tìm theo Username");
        System.out.print("Chọn cách tìm: ");
        int type = readInt();
        User u = null;
        if (type == 1) {
            System.out.print("Nhập User ID: ");
            int id = readInt();
            u = userDAO.getUserById(id);
        } else if (type == 2) {
            System.out.print("Nhập Username: ");
            String username = scanner.nextLine().trim();
            u = userDAO.getUserByUsername(username);
        } else {
            System.out.println("Lựa chọn không hợp lệ!");
            return;
        }

        if (u != null) {
            System.out.println("===> Tìm thấy User:");
            System.out.println("  ID: " + u.getUserId());
            System.out.println("  Username: " + u.getUsername());
            System.out.println("  Họ tên: " + u.getFullName());
            System.out.println("  Vai trò: " + u.getRole());
            System.out.println("  Class ID: " + (u.getClassId() == null ? "Chưa xếp lớp" : u.getClassId()));
        } else {
            System.out.println("===> Không tìm thấy User phù hợp!");
        }
    }

    private static void createUser() {
        System.out.println("\n--- THÊM MỚI USER ---");
        System.out.print("Nhập username: ");
        String username = scanner.nextLine().trim();
        if (userDAO.getUserByUsername(username) != null) {
            System.out.println("Lỗi: Username đã tồn tại trong CSDL!");
            return;
        }

        System.out.print("Nhập mật khẩu: ");
        String password = scanner.nextLine().trim();

        System.out.print("Nhập họ và tên: ");
        String fullName = scanner.nextLine().trim();

        System.out.print("Nhập vai trò (Student/Lecturer/Admin): ");
        String role = scanner.nextLine().trim();

        System.out.print("Nhập class_id (nhập 0 nếu không có): ");
        int classId = readInt();
        Integer finalClassId = (classId <= 0) ? null : classId;

        User user = new User(0, username, password, fullName, role, finalClassId);
        boolean success = userDAO.insertUser(user);
        if (success) {
            System.out.println("===> THÊM MỚI USER THÀNH CÔNG!");
        } else {
            System.out.println("===> Thêm mới thất bại! Kiểm tra lại dữ liệu hoặc khóa ngoại class_id.");
        }
    }

    private static void updateUser() {
        System.out.println("\n--- CẬP NHẬT THÔNG TIN USER ---");
        System.out.print("Nhập ID User cần cập nhật: ");
        int id = readInt();
        User u = userDAO.getUserById(id);
        if (u == null) {
            System.out.println("Không tìm thấy User có ID: " + id);
            return;
        }

        System.out.println("Đang sửa thông tin của: " + u.getUsername() + " (" + u.getFullName() + ")");
        System.out.print("Nhập họ tên mới (bỏ trống nếu giữ nguyên): ");
        String name = scanner.nextLine().trim();
        if (!name.isEmpty()) {
            u.setFullName(name);
        }

        System.out.print("Nhập vai trò mới [Student/Lecturer/Admin] (bỏ trống nếu giữ nguyên): ");
        String role = scanner.nextLine().trim();
        if (!role.isEmpty()) {
            u.setRole(role);
        }

        System.out.print("Nhập class_id mới (-1 để giữ nguyên, 0 để gán null): ");
        int cId = readInt();
        if (cId == 0) {
            u.setClassId(null);
        } else if (cId > 0) {
            u.setClassId(cId);
        }

        boolean success = userDAO.updateUser(u);
        if (success) {
            System.out.println("===> CẬP NHẬT USER THÀNH CÔNG!");
        } else {
            System.out.println("===> Cập nhật thất bại!");
        }
    }

    private static void deleteUser() {
        System.out.println("\n--- XÓA USER ---");
        System.out.print("Nhập ID User cần xóa: ");
        int id = readInt();
        User u = userDAO.getUserById(id);
        if (u == null) {
            System.out.println("Không tìm thấy User có ID: " + id);
            return;
        }

        System.out.print("Bạn có chắc chắn muốn xóa user '" + u.getUsername() + "'? (Y/N): ");
        String confirm = scanner.nextLine().trim();
        if (confirm.equalsIgnoreCase("Y")) {
            boolean success = userDAO.deleteUser(id);
            if (success) {
                System.out.println("===> ĐÃ XÓA USER THÀNH CÔNG!");
            } else {
                System.out.println("===> Xóa thất bại! (Lưu ý: User có thể đang bị ràng buộc khóa ngoại với Submissions hoặc Assignments)");
            }
        } else {
            System.out.println("Đã hủy thao tác xóa.");
        }
    }

    // =========================================================================
    // MENU ASSIGNMENT CRUD
    // =========================================================================
    private static void menuAssignment() {
        while (true) {
            System.out.println("\n------------------------------------------");
            System.out.println("    --- QUẢN LÝ ASSIGNMENTS (CRUD) ---    ");
            System.out.println("------------------------------------------");
            System.out.println("1. [READ]   Xem danh sách tất cả bài tập");
            System.out.println("2. [READ]   Xem chi tiết bài tập theo ID");
            System.out.println("3. [CREATE] Thêm mới bài tập");
            System.out.println("4. [UPDATE] Cập nhật bài tập");
            System.out.println("5. [DELETE] Xóa bài tập");
            System.out.println("0. Quay lại Menu chính");
            System.out.println("------------------------------------------");
            System.out.print("Chọn thao tác Assignment [0-5]: ");

            int choice = readInt();
            switch (choice) {
                case 1:
                    readAllAssignments();
                    break;
                case 2:
                    readAssignmentDetail();
                    break;
                case 3:
                    createAssignment();
                    break;
                case 4:
                    updateAssignment();
                    break;
                case 5:
                    deleteAssignment();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Lựa chọn không hợp lệ! Vui lòng nhập lại.");
            }
        }
    }

    private static void readAllAssignments() {
        System.out.println("\n--- DANH SÁCH BÀI TẬP (ASSIGNMENTS) ---");
        List<Assignment> list = assignmentDAO.getAllAssignments();
        if (list.isEmpty()) {
            System.out.println("Hiện chưa có bài tập nào!");
            return;
        }
        System.out.printf("%-6s | %-30s | %-20s | %-20s\n", "ID", "Tiêu đề", "Giảng viên", "Ngày tạo");
        System.out.println("-----------------------------------------------------------------------------------");
        for (Assignment a : list) {
            System.out.printf("%-6d | %-30s | %-20s | %-20s\n",
                    a.getAssignmentId(),
                    truncate(a.getTitle(), 30),
                    a.getLecturerName() == null ? ("GV ID " + a.getLecturerId()) : a.getLecturerName(),
                    a.getCreatedAt());
        }
    }

    private static void readAssignmentDetail() {
        System.out.print("\nNhập ID bài tập cần xem: ");
        int id = readInt();
        Assignment a = assignmentDAO.getAssignmentById(id);
        if (a != null) {
            System.out.println("===> CHI TIẾT BÀI TẬP:");
            System.out.println("  ID: " + a.getAssignmentId());
            System.out.println("  Tiêu đề: " + a.getTitle());
            System.out.println("  Giảng viên phụ trách: " + (a.getLecturerName() != null ? a.getLecturerName() : a.getLecturerId()));
            System.out.println("  Mô tả yêu cầu:\n" + a.getDescription());
            System.out.println("  Ngày tạo: " + a.getCreatedAt());
        } else {
            System.out.println("Không tìm thấy bài tập có ID: " + id);
        }
    }

    private static void createAssignment() {
        System.out.println("\n--- THÊM MỚI BÀI TẬP ---");
        System.out.print("Nhập ID của Giảng viên ra đề: ");
        int lecturerId = readInt();
        User gv = userDAO.getUserById(lecturerId);
        if (gv == null) {
            System.out.println("Lỗi: Không tìm thấy User ID = " + lecturerId + " trong CSDL!");
            return;
        }

        System.out.print("Nhập tiêu đề bài tập: ");
        String title = scanner.nextLine().trim();

        System.out.print("Nhập mô tả đề bài: ");
        String desc = scanner.nextLine().trim();

        Assignment a = new Assignment(0, lecturerId, null, title, desc, null);
        boolean success = assignmentDAO.insertAssignment(a);
        if (success) {
            System.out.println("===> TẠO BÀI TẬP MỚI THÀNH CÔNG!");
        } else {
            System.out.println("===> Thêm mới bài tập thất bại!");
        }
    }

    private static void updateAssignment() {
        System.out.println("\n--- CẬP NHẬT BÀI TẬP ---");
        System.out.print("Nhập ID bài tập cần sửa: ");
        int id = readInt();
        Assignment a = assignmentDAO.getAssignmentById(id);
        if (a == null) {
            System.out.println("Không tìm thấy bài tập ID: " + id);
            return;
        }

        System.out.println("Tiêu đề hiện tại: " + a.getTitle());
        System.out.print("Nhập tiêu đề mới (bỏ trống nếu giữ nguyên): ");
        String newTitle = scanner.nextLine().trim();
        if (!newTitle.isEmpty()) {
            a.setTitle(newTitle);
        }

        System.out.println("Mô tả hiện tại: " + a.getDescription());
        System.out.print("Nhập mô tả mới (bỏ trống nếu giữ nguyên): ");
        String newDesc = scanner.nextLine().trim();
        if (!newDesc.isEmpty()) {
            a.setDescription(newDesc);
        }

        boolean success = assignmentDAO.updateAssignment(a);
        if (success) {
            System.out.println("===> CẬP NHẬT BÀI TẬP THÀNH CÔNG!");
        } else {
            System.out.println("===> Cập nhật thất bại!");
        }
    }

    private static void deleteAssignment() {
        System.out.println("\n--- XÓA BÀI TẬP ---");
        System.out.print("Nhập ID bài tập cần xóa: ");
        int id = readInt();
        Assignment a = assignmentDAO.getAssignmentById(id);
        if (a == null) {
            System.out.println("Không tìm thấy bài tập ID: " + id);
            return;
        }

        System.out.print("Bạn có chắc chắn muốn xóa bài tập '" + a.getTitle() + "'? (Y/N): ");
        String confirm = scanner.nextLine().trim();
        if (confirm.equalsIgnoreCase("Y")) {
            boolean success = assignmentDAO.deleteAssignment(id);
            if (success) {
                System.out.println("===> XÓA BÀI TẬP THÀNH CÔNG!");
            } else {
                System.out.println("===> Xóa thất bại! (Bài tập này có thể đã có sinh viên nộp bài SUBMISSIONS)");
            }
        } else {
            System.out.println("Đã hủy thao tác xóa.");
        }
    }

    // =========================================================================
    // TIỆN ÍCH
    // =========================================================================
    private static int readInt() {
        while (true) {
            try {
                String line = scanner.nextLine().trim();
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.print("Vui lòng nhập số nguyên hợp lệ: ");
            }
        }
    }

    private static String truncate(String text, int maxLen) {
        if (text == null) return "";
        return text.length() > maxLen ? text.substring(0, maxLen - 3) + "..." : text;
    }
}
